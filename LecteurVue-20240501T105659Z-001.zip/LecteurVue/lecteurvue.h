#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurVue; }
QT_END_NAMESPACE

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();

public slots :
    void demanderSuivant();
    void demanderPrecedent();
    void demanderLancer();
    void demanderArret();
    void on_acCharger_triggered();
    void on_acEnlever_triggered();
    void on_acQuitter_triggered();
    void on_acAProposDe_triggered();

private:
    Ui::LecteurVue *ui;
};
#endif // LECTEURVUE_H
