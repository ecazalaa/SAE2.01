#include "lecteurvue.h"
#include "ui_lecteurvue.h"
#include <QDebug>

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    // connection SLOTS et SIGNAUX
    connect(ui->btnSuivant, SIGNAL(clicked()), this, SLOT(demanderSuivant()));
    connect(ui->btnPrecedent, SIGNAL(clicked()), this, SLOT(demanderPrecedent()));
    connect(ui->btnLancer, SIGNAL(clicked()), this, SLOT(demanderLancer()));
    connect(ui->btnArret, SIGNAL(clicked()), this, SLOT(demanderArret()));

}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::demanderSuivant()
{
    qDebug()<<"diapositive suivante demandée"<<Qt::endl;
}

void LecteurVue::demanderPrecedent()
{
    qDebug()<<"diapositive précédente demandée"<<Qt::endl;
}

void LecteurVue::demanderLancer()
{
    qDebug()<<"demande de lancement du diaporama auto"<<Qt::endl;
}

void LecteurVue::demanderArret()
{
    qDebug()<<"demande d'arrêt du diaporama auto"<<Qt::endl;
}


void LecteurVue::on_acCharger_triggered()
{
    qDebug()<<"demande de chargement d'un diaporama"<<Qt::endl;
}


void LecteurVue::on_acEnlever_triggered()
{
    qDebug()<<"demande d'enlever un diaporama"<<Qt::endl;

}


void LecteurVue::on_acQuitter_triggered()
{
    qDebug()<<"demande de quitter l'application"<<Qt::endl;
}


void LecteurVue::on_acAProposDe_triggered()
{
    qDebug()<<"demande d'informations sur l'application"<<Qt::endl;
}

